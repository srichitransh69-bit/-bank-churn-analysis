# 🏦 Bank Customer Churn Analysis & Prediction

![Python](https://img.shields.io/badge/Python-3.9+-blue?logo=python&logoColor=white)
![Scikit-learn](https://img.shields.io/badge/Scikit--learn-ML-orange?logo=scikit-learn)
![Streamlit](https://img.shields.io/badge/Streamlit-Dashboard-red?logo=streamlit)
![Pandas](https://img.shields.io/badge/Pandas-Data%20Analysis-150458?logo=pandas)
![Power BI](https://img.shields.io/badge/PowerBI-Dashboard-yellow?logo=powerbi)
![Status](https://img.shields.io/badge/Status-Complete-brightgreen)

> **End-to-end Data Analytics project** — Customer churn prediction using Exploratory Data Analysis, Machine Learning, and an interactive Streamlit dashboard with real-time prediction.

**Author:** Chitransh Srivastava  
**Role:** Data Analyst Intern | Aspiring Data Analyst & Software Engineer

---

## 🎯 Problem Statement

Customer churn is one of the most critical challenges for banking institutions. Losing a customer costs **5–10x more** than retaining one. This project aims to:

- Identify **which customers are at risk** of churning
- Understand **why customers churn** through data-driven insights
- Build a **predictive model** to flag high-risk customers early
- Provide **actionable business recommendations** to reduce churn

---

## 📊 Key Results

| Metric | Value |
|--------|-------|
| Dataset Size | 1,000 customers |
| Overall Churn Rate | 27.6% |
| Model Accuracy | 77.0% |
| AUC Score | 0.799 |
| Revenue at Risk (High-Risk segment) | ₹13.18 Million |
| High-Risk Customers Identified | 105 |

---

## 🗂️ Project Structure

```
bank-churn-analysis/
│
├── data/
│   ├── bank_churn_data.csv          # Dataset
│   └── generate_dataset.py          # Dataset generation script
│
├── src/
│   └── analysis.py                  # Full EDA + ML pipeline
│
├── dashboard/
│   └── app.py                       # Streamlit interactive dashboard
│
├── notebooks/
│   └── churn_analysis.ipynb         # Jupyter notebook walkthrough
│
├── assets/
│   ├── 01_overview_dashboard.png    # Overview charts
│   ├── 02_eda_deep_dive.png         # EDA charts
│   ├── 03_model_performance.png     # ML model charts
│   └── 04_business_insights.png     # Business insight charts
│
├── requirements.txt
└── README.md
```

---

## 🔍 Analysis Workflow

### 1. Data Collection & Understanding
- 1,000 customer records with 15 features
- Features: Demographics, Account info, Activity, Campaign history

### 2. Data Cleaning & Preprocessing
- Checked for missing values → Dataset is clean (0 nulls)
- Label encoding for categorical variables (Gender, Geography)
- Feature scaling using StandardScaler for Logistic Regression

### 3. Exploratory Data Analysis (EDA)
- Churn distribution analysis
- Correlation matrix across all features
- Segment-wise churn rates (Geography, Products, Activity)
- Age, Balance, Credit Score distributions

### 4. Feature Engineering
- Risk segmentation: Low / Medium / High Risk
- Churn probability scoring for each customer

### 5. Predictive Modelling
- **Logistic Regression** — Accuracy: 76.5%, AUC: 0.777
- **Random Forest** — Accuracy: 77.0%, AUC: 0.799 ✅ (Best Model)
- Confusion matrix, ROC curve, Feature importance analysis

### 6. Business Insights & Recommendations
- Revenue at risk quantification
- Top 10 high-risk customer identification
- Retention intervention strategy

---

## 📈 Key Findings

1. **Inactive members** are 2x more likely to churn — re-engagement campaigns essential
2. **Germany** has the highest churn rate among all geographies
3. Customers with **3–4 products** churn significantly more than those with 1–2
4. **Low tenure** (< 12 months) is the strongest predictor of churn
5. **Low balance** customers are at higher churn risk

---

## 💡 Business Recommendations

| Intervention | Target Segment | Estimated Impact |
|---|---|---|
| Loyalty Rewards Programme | High-risk, active customers | -35% churn |
| Personalised Product Offers | Medium-risk, multi-product | -28% churn |
| Re-engagement Call Campaign | Inactive members | -20% churn |
| Credit Score Improvement Plan | Low credit score customers | -17% churn |

---

## 🚀 How to Run

### 1. Clone the repository
```bash
git clone https://github.com/srichitransh69-bit/bank-churn-analysis.git
cd bank-churn-analysis
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Generate dataset
```bash
python data/generate_dataset.py
```

### 4. Run full analysis (generates all charts)
```bash
python src/analysis.py
```

### 5. Launch interactive dashboard
```bash
streamlit run dashboard/app.py
```

---

## 🛠️ Tech Stack

| Tool | Purpose |
|------|---------|
| Python 3.9+ | Core language |
| Pandas & NumPy | Data manipulation & analysis |
| Matplotlib & Seaborn | Static data visualisations |
| Scikit-learn | Machine learning models |
| Streamlit | Interactive web dashboard |
| Power BI | Business intelligence dashboard |
| Git & GitHub | Version control |

---

## 📸 Dashboard Screenshots

### Overview Dashboard
![Overview](assets/01_overview_dashboard.png)

### EDA Deep Dive
![EDA](assets/02_eda_deep_dive.png)

### ML Model Performance
![Model](assets/03_model_performance.png)

### Business Insights
![Insights](assets/04_business_insights.png)

---

## 👤 About the Author

**Chitransh Srivastava**  
Data Analytics & Software Development Intern @ Skillified Mentor  
B.Tech CSE — Feroze Gandhi Institute of Engineering and Technology

- 🔗 [LinkedIn](https://www.linkedin.com/in/chitransh-srivastava-519a5633a)
- 💻 [GitHub](https://github.com/srichitransh69-bit)
- 📧 srichitransh69@gmail.com

---

## 📄 License

This project is open source and available under the [MIT License](LICENSE).
