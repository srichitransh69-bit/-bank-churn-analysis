"""
Bank Customer Churn Analysis
Author: Chitransh Srivastava
Description: End-to-end Data Analysis pipeline - EDA, Feature Engineering,
             Predictive Modelling, and Business Insights
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (classification_report, confusion_matrix,
                             roc_auc_score, roc_curve, accuracy_score)
import warnings
warnings.filterwarnings('ignore')

# ── Styling ───────────────────────────────────────────────────────────────────
NAVY   = '#1B3A6B'
BLUE   = '#2E6FC4'
RED    = '#C0392B'
GREEN  = '#27AE60'
ORANGE = '#E67E22'
GRAY   = '#95A5A6'
BG     = '#F8F9FA'

plt.rcParams.update({
    'figure.facecolor': BG,
    'axes.facecolor':   BG,
    'axes.spines.top':   False,
    'axes.spines.right': False,
    'font.family': 'DejaVu Sans',
    'axes.titlesize': 13,
    'axes.titleweight': 'bold',
    'axes.titlecolor': NAVY,
})

# ── Load Data ─────────────────────────────────────────────────────────────────
df = pd.read_csv('data/bank_churn_data.csv')
print("=" * 60)
print("BANK CUSTOMER CHURN ANALYSIS")
print("=" * 60)
print(f"\n📊 Dataset Shape : {df.shape}")
print(f"📋 Columns       : {list(df.columns)}")
print(f"\n🔍 Missing Values:\n{df.isnull().sum()}")
print(f"\n📈 Churn Rate    : {df['Churn'].mean()*100:.1f}%")
print(f"   Churned       : {df['Churn'].sum()}")
print(f"   Retained      : {(df['Churn']==0).sum()}")

# ── FIGURE 1: Overview Dashboard ──────────────────────────────────────────────
fig, axes = plt.subplots(2, 3, figsize=(18, 11))
fig.suptitle('Bank Customer Churn — Overview Dashboard', fontsize=17,
             fontweight='bold', color=NAVY, y=1.01)
fig.patch.set_facecolor(BG)

# 1a. Churn distribution (donut)
ax = axes[0, 0]
sizes  = [df['Churn'].sum(), (df['Churn']==0).sum()]
colors = [RED, GREEN]
wedges, texts, autotexts = ax.pie(
    sizes, labels=['Churned', 'Retained'], autopct='%1.1f%%',
    colors=colors, startangle=90,
    wedgeprops=dict(width=0.55, edgecolor='white', linewidth=2),
    textprops={'fontsize': 11}
)
for at in autotexts:
    at.set_fontweight('bold'); at.set_color('white'); at.set_fontsize(12)
ax.set_title('Churn Distribution')

# 1b. Churn by Geography
ax = axes[0, 1]
geo = df.groupby('Geography')['Churn'].mean() * 100
bars = ax.bar(geo.index, geo.values,
              color=[NAVY, BLUE, ORANGE], edgecolor='white', linewidth=1.5, width=0.55)
for bar, val in zip(bars, geo.values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
            f'{val:.1f}%', ha='center', fontsize=11, fontweight='bold', color=NAVY)
ax.set_title('Churn Rate by Geography')
ax.set_ylabel('Churn Rate (%)')
ax.set_ylim(0, geo.max() * 1.25)

# 1c. Churn by Number of Products
ax = axes[0, 2]
prod = df.groupby('NumOfProducts')['Churn'].mean() * 100
bars = ax.bar(prod.index.astype(str), prod.values,
              color=[GREEN, BLUE, ORANGE, RED], edgecolor='white', linewidth=1.5, width=0.55)
for bar, val in zip(bars, prod.values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
            f'{val:.1f}%', ha='center', fontsize=11, fontweight='bold', color=NAVY)
ax.set_title('Churn Rate by No. of Products')
ax.set_xlabel('Number of Products')
ax.set_ylabel('Churn Rate (%)')
ax.set_ylim(0, prod.max() * 1.25)

# 1d. Age distribution by churn
ax = axes[1, 0]
ax.hist(df[df['Churn']==0]['Age'], bins=25, color=GREEN, alpha=0.7, label='Retained', edgecolor='white')
ax.hist(df[df['Churn']==1]['Age'], bins=25, color=RED,   alpha=0.7, label='Churned',  edgecolor='white')
ax.set_title('Age Distribution by Churn')
ax.set_xlabel('Age')
ax.set_ylabel('Count')
ax.legend(fontsize=10)

# 1e. Balance distribution by churn
ax = axes[1, 1]
ax.hist(df[df['Churn']==0]['Balance']/1000, bins=25, color=GREEN, alpha=0.7, label='Retained', edgecolor='white')
ax.hist(df[df['Churn']==1]['Balance']/1000, bins=25, color=RED,   alpha=0.7, label='Churned',  edgecolor='white')
ax.set_title('Balance Distribution by Churn')
ax.set_xlabel('Balance (₹ Thousands)')
ax.set_ylabel('Count')
ax.legend(fontsize=10)

# 1f. Active vs Inactive churn
ax = axes[1, 2]
act = df.groupby('IsActiveMember')['Churn'].mean() * 100
labels = ['Inactive', 'Active']
bars = ax.bar(labels, act.values, color=[RED, GREEN], edgecolor='white', linewidth=1.5, width=0.5)
for bar, val in zip(bars, act.values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
            f'{val:.1f}%', ha='center', fontsize=12, fontweight='bold', color=NAVY)
ax.set_title('Churn Rate: Active vs Inactive Members')
ax.set_ylabel('Churn Rate (%)')
ax.set_ylim(0, act.max() * 1.3)

plt.tight_layout()
plt.savefig('assets/01_overview_dashboard.png', dpi=150, bbox_inches='tight')
plt.close()
print("\n✅ Saved: 01_overview_dashboard.png")

# ── FIGURE 2: EDA Deep Dive ───────────────────────────────────────────────────
fig, axes = plt.subplots(2, 3, figsize=(18, 11))
fig.suptitle('Exploratory Data Analysis — Deep Dive', fontsize=17,
             fontweight='bold', color=NAVY, y=1.01)
fig.patch.set_facecolor(BG)

# 2a. Credit Score by Churn (box)
ax = axes[0, 0]
churn0 = df[df['Churn']==0]['CreditScore']
churn1 = df[df['Churn']==1]['CreditScore']
bp = ax.boxplot([churn0, churn1], patch_artist=True,
                boxprops=dict(linewidth=1.5),
                medianprops=dict(color='white', linewidth=2.5),
                whiskerprops=dict(linewidth=1.5),
                capprops=dict(linewidth=1.5))
bp['boxes'][0].set_facecolor(GREEN)
bp['boxes'][1].set_facecolor(RED)
ax.set_xticks([1,2]); ax.set_xticklabels(['Retained','Churned'])
ax.set_title('Credit Score Distribution by Churn')
ax.set_ylabel('Credit Score')

# 2b. Tenure vs Churn rate (line)
ax = axes[0, 1]
tenure_churn = df.groupby('Tenure')['Churn'].mean() * 100
ax.plot(tenure_churn.index, tenure_churn.values, color=NAVY, linewidth=2.5, marker='o', markersize=5)
ax.fill_between(tenure_churn.index, tenure_churn.values, alpha=0.15, color=NAVY)
ax.set_title('Churn Rate by Tenure (Months)')
ax.set_xlabel('Tenure (Months)')
ax.set_ylabel('Churn Rate (%)')

# 2c. Salary distribution
ax = axes[0, 2]
ax.hist(df[df['Churn']==0]['EstimatedSalary']/1000, bins=25, color=GREEN, alpha=0.7, label='Retained', edgecolor='white')
ax.hist(df[df['Churn']==1]['EstimatedSalary']/1000, bins=25, color=RED,   alpha=0.7, label='Churned',  edgecolor='white')
ax.set_title('Estimated Salary Distribution')
ax.set_xlabel('Salary (₹ Thousands)')
ax.set_ylabel('Count')
ax.legend(fontsize=10)

# 2d. Gender churn grouped bar
ax = axes[1, 0]
gender_churn = df.groupby(['Gender','Churn']).size().unstack()
x = np.arange(len(gender_churn))
width = 0.35
ax.bar(x - width/2, gender_churn[0], width, label='Retained', color=GREEN, edgecolor='white')
ax.bar(x + width/2, gender_churn[1], width, label='Churned',  color=RED,   edgecolor='white')
ax.set_xticks(x); ax.set_xticklabels(gender_churn.index)
ax.set_title('Churn Count by Gender')
ax.set_ylabel('Count')
ax.legend(fontsize=10)

# 2e. Correlation heatmap
ax = axes[1, 1]
num_cols = ['Age','CreditScore','Tenure','Balance','NumOfProducts',
            'EstimatedSalary','CampaignCalls','Churn']
corr = df[num_cols].corr()
mask = np.triu(np.ones_like(corr, dtype=bool))
sns.heatmap(corr, mask=mask, ax=ax, annot=True, fmt='.2f', cmap='coolwarm',
            center=0, linewidths=0.5, annot_kws={'size': 8},
            cbar_kws={'shrink': 0.8})
ax.set_title('Feature Correlation Matrix')
ax.tick_params(axis='x', rotation=45, labelsize=8)
ax.tick_params(axis='y', rotation=0,  labelsize=8)

# 2f. Campaign calls vs churn
ax = axes[1, 2]
camp = df.groupby('CampaignCalls')['Churn'].mean() * 100
ax.bar(camp.index, camp.values, color=BLUE, edgecolor='white', linewidth=1.2)
ax.set_title('Churn Rate by No. of Campaign Calls')
ax.set_xlabel('Campaign Calls')
ax.set_ylabel('Churn Rate (%)')

plt.tight_layout()
plt.savefig('assets/02_eda_deep_dive.png', dpi=150, bbox_inches='tight')
plt.close()
print("✅ Saved: 02_eda_deep_dive.png")

# ── Model Preparation ─────────────────────────────────────────────────────────
print("\n" + "="*60)
print("MACHINE LEARNING MODEL")
print("="*60)

df_model = df.copy()
le = LabelEncoder()
df_model['Gender']    = le.fit_transform(df_model['Gender'])
df_model['Geography'] = le.fit_transform(df_model['Geography'])

features = ['Age','Gender','Geography','CreditScore','Tenure','Balance',
            'NumOfProducts','HasCrCard','IsActiveMember','EstimatedSalary',
            'CampaignCalls','LastContactDays']
X = df_model[features]
y = df_model['Churn']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

scaler  = StandardScaler()
X_train_sc = scaler.fit_transform(X_train)
X_test_sc  = scaler.transform(X_test)

# Logistic Regression
lr = LogisticRegression(max_iter=1000, random_state=42)
lr.fit(X_train_sc, y_train)
lr_pred  = lr.predict(X_test_sc)
lr_proba = lr.predict_proba(X_test_sc)[:,1]
lr_acc   = accuracy_score(y_test, lr_pred)
lr_auc   = roc_auc_score(y_test, lr_proba)

# Random Forest
rf = RandomForestClassifier(n_estimators=100, random_state=42, max_depth=8)
rf.fit(X_train, y_train)
rf_pred  = rf.predict(X_test)
rf_proba = rf.predict_proba(X_test)[:,1]
rf_acc   = accuracy_score(y_test, rf_pred)
rf_auc   = roc_auc_score(y_test, rf_proba)

print(f"\n📌 Logistic Regression  → Accuracy: {lr_acc*100:.1f}%  |  AUC: {lr_auc:.3f}")
print(f"📌 Random Forest        → Accuracy: {rf_acc*100:.1f}%  |  AUC: {rf_auc:.3f}")
print(f"\n{classification_report(y_test, rf_pred, target_names=['Retained','Churned'])}")

# ── FIGURE 3: Model Performance ───────────────────────────────────────────────
fig, axes = plt.subplots(1, 3, figsize=(18, 6))
fig.suptitle('Machine Learning Model Performance', fontsize=17,
             fontweight='bold', color=NAVY)
fig.patch.set_facecolor(BG)

# 3a. Confusion matrix (RF)
ax = axes[0]
cm = confusion_matrix(y_test, rf_pred)
sns.heatmap(cm, annot=True, fmt='d', ax=ax,
            cmap=sns.color_palette([BG, NAVY], as_cmap=True),
            xticklabels=['Retained','Churned'],
            yticklabels=['Retained','Churned'],
            linewidths=2, linecolor='white',
            annot_kws={'size': 16, 'weight': 'bold'})
ax.set_title('Confusion Matrix — Random Forest')
ax.set_xlabel('Predicted', fontweight='bold')
ax.set_ylabel('Actual',    fontweight='bold')

# 3b. ROC Curves
ax = axes[1]
fpr_lr, tpr_lr, _ = roc_curve(y_test, lr_proba)
fpr_rf, tpr_rf, _ = roc_curve(y_test, rf_proba)
ax.plot(fpr_lr, tpr_lr, color=BLUE,  linewidth=2.5, label=f'Logistic Reg (AUC={lr_auc:.2f})')
ax.plot(fpr_rf, tpr_rf, color=NAVY,  linewidth=2.5, label=f'Random Forest (AUC={rf_auc:.2f})')
ax.plot([0,1],[0,1], '--', color=GRAY, linewidth=1.5, label='Random Classifier')
ax.fill_between(fpr_rf, tpr_rf, alpha=0.08, color=NAVY)
ax.set_title('ROC Curve Comparison')
ax.set_xlabel('False Positive Rate')
ax.set_ylabel('True Positive Rate')
ax.legend(fontsize=10)

# 3c. Feature Importance
ax = axes[2]
importances = pd.Series(rf.feature_importances_, index=features).sort_values(ascending=True)
colors_fi = [RED if v == importances.max() else BLUE if v >= importances.quantile(0.7) else GRAY
             for v in importances.values]
bars = ax.barh(importances.index, importances.values, color=colors_fi, edgecolor='white', height=0.65)
ax.set_title('Feature Importance — Random Forest')
ax.set_xlabel('Importance Score')
for bar, val in zip(bars, importances.values):
    ax.text(val + 0.002, bar.get_y() + bar.get_height()/2,
            f'{val:.3f}', va='center', fontsize=9, color=NAVY)

plt.tight_layout()
plt.savefig('assets/03_model_performance.png', dpi=150, bbox_inches='tight')
plt.close()
print("\n✅ Saved: 03_model_performance.png")

# ── FIGURE 4: Business Insights ───────────────────────────────────────────────
fig, axes = plt.subplots(1, 3, figsize=(18, 6))
fig.suptitle('Business Insights & Recommendations', fontsize=17,
             fontweight='bold', color=NAVY)
fig.patch.set_facecolor(BG)

# 4a. Revenue at risk
ax = axes[0]
df['ChurnRisk'] = rf.predict_proba(X)[:,1]
df['RiskSegment'] = pd.cut(df['ChurnRisk'], bins=[0,0.3,0.6,1.0],
                           labels=['Low Risk','Medium Risk','High Risk'])
risk_rev = df.groupby('RiskSegment')['Balance'].sum() / 1e6
bars = ax.bar(risk_rev.index, risk_rev.values,
              color=[GREEN, ORANGE, RED], edgecolor='white', linewidth=1.5, width=0.55)
for bar, val in zip(bars, risk_rev.values):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
            f'₹{val:.1f}M', ha='center', fontsize=11, fontweight='bold', color=NAVY)
ax.set_title('Revenue at Risk by Segment')
ax.set_ylabel('Total Balance (₹ Millions)')

# 4b. Top 10 high-risk customers
ax = axes[1]
top10 = df.nlargest(10, 'ChurnRisk')[['CustomerID','ChurnRisk','Balance']]
colors_bar = [RED if v > 0.8 else ORANGE for v in top10['ChurnRisk']]
bars = ax.barh(top10['CustomerID'], top10['ChurnRisk']*100,
               color=colors_bar, edgecolor='white', height=0.65)
ax.set_title('Top 10 High-Risk Customers')
ax.set_xlabel('Churn Probability (%)')
ax.set_xlim(0, 110)
for bar, val in zip(bars, top10['ChurnRisk'].values):
    ax.text(val*100 + 1, bar.get_y() + bar.get_height()/2,
            f'{val*100:.1f}%', va='center', fontsize=9, fontweight='bold', color=NAVY)

# 4c. Recommended interventions
ax = axes[2]
interventions = {
    'Loyalty\nRewards': 35,
    'Personalised\nOffers': 28,
    'Re-engagement\nCalls': 20,
    'Credit Score\nImprovement': 17
}
bars = ax.bar(interventions.keys(), interventions.values(),
              color=[NAVY, BLUE, ORANGE, GREEN], edgecolor='white', linewidth=1.5, width=0.55)
for bar, val in zip(bars, interventions.values()):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.4,
            f'{val}%', ha='center', fontsize=12, fontweight='bold', color=NAVY)
ax.set_title('Recommended Retention Interventions\n(% Impact Estimate)')
ax.set_ylabel('Estimated Churn Reduction (%)')
ax.set_ylim(0, 45)

plt.tight_layout()
plt.savefig('assets/04_business_insights.png', dpi=150, bbox_inches='tight')
plt.close()
print("✅ Saved: 04_business_insights.png")

# ── Summary Report ────────────────────────────────────────────────────────────
print("\n" + "="*60)
print("BUSINESS SUMMARY")
print("="*60)
high_risk = df[df['RiskSegment']=='High Risk']
print(f"\n⚠️  High-risk customers : {len(high_risk)}")
print(f"💰  Revenue at risk     : ₹{high_risk['Balance'].sum()/1e6:.2f} Million")
print(f"🎯  Model Accuracy      : {rf_acc*100:.1f}%")
print(f"📊  Model AUC Score     : {rf_auc:.3f}")
print(f"\n✅  All charts saved to /assets/")
print("="*60)
