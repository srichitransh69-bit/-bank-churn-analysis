"""
Bank Customer Churn Analysis — Interactive Dashboard
Author: Chitransh Srivastava
Run: streamlit run dashboard/app.py
"""

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, accuracy_score, confusion_matrix, roc_curve
import warnings
warnings.filterwarnings('ignore')

# ── Page Config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Bank Churn Analysis | Chitransh Srivastava",
    page_icon="🏦",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ── Theme ─────────────────────────────────────────────────────────────────────
NAVY   = '#1B3A6B'
BLUE   = '#2E6FC4'
RED    = '#C0392B'
GREEN  = '#27AE60'
ORANGE = '#E67E22'
GRAY   = '#95A5A6'
BG     = '#F8F9FA'

st.markdown("""
<style>
    .main { background-color: #F8F9FA; }
    .block-container { padding-top: 1.5rem; }
    h1 { color: #1B3A6B !important; }
    h2, h3 { color: #1B3A6B !important; }
    .metric-card {
        background: white;
        border-left: 4px solid #1B3A6B;
        border-radius: 8px;
        padding: 16px 20px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        margin-bottom: 10px;
    }
    .metric-value { font-size: 2rem; font-weight: 700; color: #1B3A6B; }
    .metric-label { font-size: 0.85rem; color: #555; margin-top: 2px; }
    .insight-box {
        background: #EBF5FB;
        border-left: 4px solid #2E6FC4;
        border-radius: 6px;
        padding: 12px 16px;
        margin: 8px 0;
        font-size: 0.92rem;
        color: #2D2D2D;
    }
    .warning-box {
        background: #FDEDEC;
        border-left: 4px solid #C0392B;
        border-radius: 6px;
        padding: 12px 16px;
        margin: 8px 0;
        font-size: 0.92rem;
    }
    .stSelectbox label, .stSlider label { color: #1B3A6B !important; font-weight: 600; }
</style>
""", unsafe_allow_html=True)

# ── Load & Cache Data ─────────────────────────────────────────────────────────
@st.cache_data
def load_data():
    df = pd.read_csv('data/bank_churn_data.csv')
    return df

@st.cache_resource
def train_models(df):
    df_m = df.copy()
    le = LabelEncoder()
    df_m['Gender']    = le.fit_transform(df_m['Gender'])
    df_m['Geography'] = le.fit_transform(df_m['Geography'])

    features = ['Age','Gender','Geography','CreditScore','Tenure','Balance',
                'NumOfProducts','HasCrCard','IsActiveMember','EstimatedSalary',
                'CampaignCalls','LastContactDays']
    X = df_m[features]; y = df_m['Churn']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2,
                                                         random_state=42, stratify=y)
    scaler = StandardScaler()
    X_sc = scaler.fit_transform(X_train)
    Xt_sc = scaler.transform(X_test)

    rf = RandomForestClassifier(n_estimators=100, random_state=42, max_depth=8)
    rf.fit(X_train, y_train)
    lr = LogisticRegression(max_iter=1000, random_state=42)
    lr.fit(X_sc, y_train)

    df['ChurnProb'] = rf.predict_proba(df_m[features])[:,1]
    df['RiskSegment'] = pd.cut(df['ChurnProb'], bins=[0,0.3,0.6,1.0],
                               labels=['Low Risk','Medium Risk','High Risk'])
    return rf, lr, scaler, X_test, Xt_sc, y_test, features, df

df = load_data()
rf, lr, scaler, X_test, Xt_sc, y_test, features, df = train_models(df)

rf_acc = accuracy_score(y_test, rf.predict(X_test))
rf_auc = roc_auc_score(y_test, rf.predict_proba(X_test)[:,1])
lr_auc = roc_auc_score(y_test, lr.predict_proba(Xt_sc)[:,1])

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown(f"<h2 style='color:{NAVY}'>🏦 Churn Analysis</h2>", unsafe_allow_html=True)
    st.markdown("**By Chitransh Srivastava**")
    st.markdown("---")
    st.markdown("### 🔎 Filters")
    geo_filter  = st.multiselect("Geography", df['Geography'].unique(), default=list(df['Geography'].unique()))
    age_range   = st.slider("Age Range", int(df['Age'].min()), int(df['Age'].max()), (18, 70))
    risk_filter = st.multiselect("Risk Segment", ['Low Risk','Medium Risk','High Risk'],
                                  default=['Low Risk','Medium Risk','High Risk'])
    st.markdown("---")
    st.markdown("### 📊 Model Info")
    st.markdown(f"- **Accuracy:** {rf_acc*100:.1f}%")
    st.markdown(f"- **AUC Score:** {rf_auc:.3f}")
    st.markdown(f"- **Algorithm:** Random Forest")
    st.markdown(f"- **Dataset:** {len(df):,} customers")

# Apply filters
mask = (
    df['Geography'].isin(geo_filter) &
    df['Age'].between(age_range[0], age_range[1]) &
    df['RiskSegment'].isin(risk_filter)
)
dff = df[mask]

# ── Header ────────────────────────────────────────────────────────────────────
st.markdown(f"<h1>🏦 Bank Customer Churn Analysis Dashboard</h1>", unsafe_allow_html=True)
st.markdown(f"*Analysing {len(dff):,} customers after filters • Predictive Modelling + Business Insights*")
st.markdown("---")

# ── KPI Metrics ───────────────────────────────────────────────────────────────
col1, col2, col3, col4, col5 = st.columns(5)
metrics = [
    (col1, "👥 Total Customers",     f"{len(dff):,}",                            "filtered dataset"),
    (col2, "⚠️ Churned",             f"{dff['Churn'].sum():,}",                   f"{dff['Churn'].mean()*100:.1f}% rate"),
    (col3, "✅ Retained",             f"{(dff['Churn']==0).sum():,}",             f"{(1-dff['Churn'].mean())*100:.1f}%"),
    (col4, "🔴 High Risk",           f"{(dff['RiskSegment']=='High Risk').sum():,}", "customers flagged"),
    (col5, "💰 Revenue at Risk",     f"₹{dff[dff['RiskSegment']=='High Risk']['Balance'].sum()/1e6:.1f}M", "high-risk balance"),
]
for col, label, value, sub in metrics:
    with col:
        st.markdown(f"""
        <div class='metric-card'>
            <div style='font-size:0.8rem;color:#555'>{label}</div>
            <div class='metric-value'>{value}</div>
            <div class='metric-label'>{sub}</div>
        </div>""", unsafe_allow_html=True)

st.markdown("---")

# ── Tabs ──────────────────────────────────────────────────────────────────────
tab1, tab2, tab3, tab4 = st.tabs(["📊 Overview", "🔬 EDA", "🤖 ML Model", "🎯 Predict"])

# ── TAB 1: Overview ───────────────────────────────────────────────────────────
with tab1:
    st.subheader("Churn Distribution & Key Patterns")
    col1, col2 = st.columns(2)

    with col1:
        fig, ax = plt.subplots(figsize=(6, 4), facecolor=BG)
        ax.set_facecolor(BG)
        sizes  = [dff['Churn'].sum(), (dff['Churn']==0).sum()]
        wedges, texts, autotexts = ax.pie(
            sizes, labels=['Churned','Retained'], autopct='%1.1f%%',
            colors=[RED, GREEN], startangle=90,
            wedgeprops=dict(width=0.55, edgecolor='white', linewidth=2))
        for at in autotexts:
            at.set_fontweight('bold'); at.set_color('white'); at.set_fontsize(11)
        ax.set_title('Churn Distribution', fontweight='bold', color=NAVY)
        ax.spines[['top','right','left','bottom']].set_visible(False)
        st.pyplot(fig, use_container_width=True); plt.close()

    with col2:
        fig, ax = plt.subplots(figsize=(6, 4), facecolor=BG)
        ax.set_facecolor(BG)
        geo = dff.groupby('Geography')['Churn'].mean() * 100
        bars = ax.bar(geo.index, geo.values, color=[NAVY, BLUE, ORANGE],
                      edgecolor='white', linewidth=1.5, width=0.5)
        for bar, val in zip(bars, geo.values):
            ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
                    f'{val:.1f}%', ha='center', fontweight='bold', color=NAVY)
        ax.set_title('Churn Rate by Geography', fontweight='bold', color=NAVY)
        ax.set_ylabel('Churn Rate (%)'); ax.set_ylim(0, geo.max() * 1.3)
        ax.spines[['top','right']].set_visible(False)
        st.pyplot(fig, use_container_width=True); plt.close()

    col3, col4 = st.columns(2)
    with col3:
        fig, ax = plt.subplots(figsize=(6, 4), facecolor=BG)
        ax.set_facecolor(BG)
        prod = dff.groupby('NumOfProducts')['Churn'].mean() * 100
        ax.bar(prod.index.astype(str), prod.values,
               color=[GREEN, BLUE, ORANGE, RED], edgecolor='white', linewidth=1.5, width=0.5)
        ax.set_title('Churn by No. of Products', fontweight='bold', color=NAVY)
        ax.set_xlabel('Number of Products'); ax.set_ylabel('Churn Rate (%)')
        ax.spines[['top','right']].set_visible(False)
        st.pyplot(fig, use_container_width=True); plt.close()

    with col4:
        fig, ax = plt.subplots(figsize=(6, 4), facecolor=BG)
        ax.set_facecolor(BG)
        act = dff.groupby('IsActiveMember')['Churn'].mean() * 100
        bars = ax.bar(['Inactive','Active'], act.values,
                      color=[RED, GREEN], edgecolor='white', linewidth=1.5, width=0.45)
        for bar, val in zip(bars, act.values):
            ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
                    f'{val:.1f}%', ha='center', fontweight='bold', color=NAVY, fontsize=12)
        ax.set_title('Active vs Inactive Member Churn', fontweight='bold', color=NAVY)
        ax.set_ylabel('Churn Rate (%)')
        ax.spines[['top','right']].set_visible(False)
        st.pyplot(fig, use_container_width=True); plt.close()

    st.markdown("### 💡 Key Business Insights")
    insights = [
        "🔴 <b>27.6%</b> overall churn rate — significantly above the industry benchmark of 15–20%",
        "🌍 <b>Germany</b> shows the highest churn rate among all geographies — targeted retention needed",
        "📦 Customers with <b>3–4 products</b> churn far more than those with 1–2 products",
        "😴 <b>Inactive members</b> are 2x more likely to churn — re-engagement campaigns are critical",
        "💰 <b>₹13.18 Million</b> in customer balances are at high churn risk",
    ]
    for ins in insights:
        st.markdown(f"<div class='insight-box'>{ins}</div>", unsafe_allow_html=True)

# ── TAB 2: EDA ────────────────────────────────────────────────────────────────
with tab2:
    st.subheader("Exploratory Data Analysis")
    col1, col2 = st.columns(2)

    with col1:
        fig, ax = plt.subplots(figsize=(6, 4), facecolor=BG)
        ax.set_facecolor(BG)
        ax.hist(dff[dff['Churn']==0]['Age'], bins=20, color=GREEN, alpha=0.7, label='Retained', edgecolor='white')
        ax.hist(dff[dff['Churn']==1]['Age'], bins=20, color=RED,   alpha=0.7, label='Churned',  edgecolor='white')
        ax.set_title('Age Distribution by Churn', fontweight='bold', color=NAVY)
        ax.set_xlabel('Age'); ax.set_ylabel('Count'); ax.legend()
        ax.spines[['top','right']].set_visible(False)
        st.pyplot(fig, use_container_width=True); plt.close()

    with col2:
        fig, ax = plt.subplots(figsize=(6, 4), facecolor=BG)
        ax.set_facecolor(BG)
        tenure_c = dff.groupby('Tenure')['Churn'].mean() * 100
        ax.plot(tenure_c.index, tenure_c.values, color=NAVY, linewidth=2.5, marker='o', markersize=4)
        ax.fill_between(tenure_c.index, tenure_c.values, alpha=0.1, color=NAVY)
        ax.set_title('Churn Rate by Tenure', fontweight='bold', color=NAVY)
        ax.set_xlabel('Tenure (Months)'); ax.set_ylabel('Churn Rate (%)')
        ax.spines[['top','right']].set_visible(False)
        st.pyplot(fig, use_container_width=True); plt.close()

    # Correlation heatmap
    st.subheader("Feature Correlation Matrix")
    num_cols = ['Age','CreditScore','Tenure','Balance','NumOfProducts','EstimatedSalary','CampaignCalls','Churn']
    fig, ax = plt.subplots(figsize=(9, 5), facecolor=BG)
    ax.set_facecolor(BG)
    sns.heatmap(dff[num_cols].corr(), annot=True, fmt='.2f', cmap='coolwarm',
                center=0, ax=ax, linewidths=0.5, annot_kws={'size': 10})
    ax.set_title('Feature Correlation Matrix', fontweight='bold', color=NAVY)
    st.pyplot(fig, use_container_width=True); plt.close()

    # Raw data
    st.subheader("📋 Raw Data Explorer")
    st.dataframe(dff.head(100), use_container_width=True, height=300)

# ── TAB 3: ML Model ───────────────────────────────────────────────────────────
with tab3:
    st.subheader("Machine Learning Model Performance")
    col1, col2, col3 = st.columns(3)
    col1.metric("Model",    "Random Forest")
    col2.metric("Accuracy", f"{rf_acc*100:.1f}%")
    col3.metric("AUC Score", f"{rf_auc:.3f}")

    col1, col2 = st.columns(2)
    with col1:
        fig, ax = plt.subplots(figsize=(6, 4.5), facecolor=BG)
        ax.set_facecolor(BG)
        cm = confusion_matrix(y_test, rf.predict(X_test))
        sns.heatmap(cm, annot=True, fmt='d', ax=ax,
                    cmap=sns.color_palette([BG, NAVY], as_cmap=True),
                    xticklabels=['Retained','Churned'],
                    yticklabels=['Retained','Churned'],
                    linewidths=2, linecolor='white',
                    annot_kws={'size': 16, 'weight': 'bold'})
        ax.set_title('Confusion Matrix', fontweight='bold', color=NAVY)
        ax.set_xlabel('Predicted', fontweight='bold')
        ax.set_ylabel('Actual',    fontweight='bold')
        st.pyplot(fig, use_container_width=True); plt.close()

    with col2:
        fig, ax = plt.subplots(figsize=(6, 4.5), facecolor=BG)
        ax.set_facecolor(BG)
        fpr_lr, tpr_lr, _ = roc_curve(y_test, lr.predict_proba(Xt_sc)[:,1])
        fpr_rf, tpr_rf, _ = roc_curve(y_test, rf.predict_proba(X_test)[:,1])
        ax.plot(fpr_lr, tpr_lr, color=BLUE, linewidth=2.5, label=f'Logistic Reg (AUC={lr_auc:.2f})')
        ax.plot(fpr_rf, tpr_rf, color=NAVY, linewidth=2.5, label=f'Random Forest (AUC={rf_auc:.2f})')
        ax.plot([0,1],[0,1], '--', color=GRAY, linewidth=1.5)
        ax.fill_between(fpr_rf, tpr_rf, alpha=0.08, color=NAVY)
        ax.set_title('ROC Curve', fontweight='bold', color=NAVY)
        ax.set_xlabel('False Positive Rate'); ax.set_ylabel('True Positive Rate')
        ax.legend(fontsize=10)
        ax.spines[['top','right']].set_visible(False)
        st.pyplot(fig, use_container_width=True); plt.close()

    # Feature importance
    st.subheader("Feature Importance")
    fi = pd.Series(rf.feature_importances_, index=features).sort_values(ascending=True)
    fig, ax = plt.subplots(figsize=(10, 5), facecolor=BG)
    ax.set_facecolor(BG)
    colors_fi = [RED if v == fi.max() else BLUE if v >= fi.quantile(0.7) else GRAY for v in fi.values]
    ax.barh(fi.index, fi.values, color=colors_fi, edgecolor='white', height=0.65)
    ax.set_title('Feature Importance — Random Forest', fontweight='bold', color=NAVY)
    ax.set_xlabel('Importance Score')
    ax.spines[['top','right']].set_visible(False)
    st.pyplot(fig, use_container_width=True); plt.close()

# ── TAB 4: Predict ────────────────────────────────────────────────────────────
with tab4:
    st.subheader("🎯 Predict Churn for a Single Customer")
    st.markdown("Enter customer details below to get an instant churn probability prediction.")

    col1, col2, col3 = st.columns(3)
    with col1:
        age        = st.slider("Age", 18, 70, 35)
        credit     = st.slider("Credit Score", 300, 850, 650)
        tenure     = st.slider("Tenure (months)", 0, 72, 24)
        balance    = st.number_input("Account Balance (₹)", 0, 250000, 50000, step=5000)
    with col2:
        num_prod   = st.selectbox("Number of Products", [1,2,3,4])
        has_card   = st.selectbox("Has Credit Card", ["Yes","No"])
        is_active  = st.selectbox("Is Active Member", ["Yes","No"])
        salary     = st.number_input("Estimated Salary (₹)", 15000, 200000, 75000, step=5000)
    with col3:
        gender     = st.selectbox("Gender", ["Male","Female"])
        geography  = st.selectbox("Geography", ["India","Germany","France"])
        camp_calls = st.slider("Campaign Calls", 0, 10, 2)
        last_cont  = st.slider("Last Contact (days ago)", 1, 365, 90)

    if st.button("🔮 Predict Churn Probability", use_container_width=True):
        geo_map = {'India': 1, 'Germany': 0, 'France': 2}
        input_data = np.array([[
            age, 1 if gender=="Male" else 0, geo_map[geography], credit, tenure,
            balance, num_prod, 1 if has_card=="Yes" else 0,
            1 if is_active=="Yes" else 0, salary, camp_calls, last_cont
        ]])
        prob = rf.predict_proba(input_data)[0][1]
        risk = "🔴 HIGH RISK" if prob > 0.6 else "🟡 MEDIUM RISK" if prob > 0.3 else "🟢 LOW RISK"
        color = RED if prob > 0.6 else ORANGE if prob > 0.3 else GREEN

        st.markdown(f"""
        <div style='background:white;border-left:6px solid {color};border-radius:10px;
                    padding:24px;margin-top:16px;box-shadow:0 4px 12px rgba(0,0,0,0.1)'>
            <h2 style='color:{color};margin:0'>{risk}</h2>
            <h1 style='color:{color};margin:8px 0;font-size:3rem'>{prob*100:.1f}%</h1>
            <p style='color:#555;margin:0'>Predicted churn probability for this customer</p>
        </div>""", unsafe_allow_html=True)

        if prob > 0.6:
            recs = ["📞 Assign dedicated relationship manager immediately",
                    "🎁 Offer personalised loyalty rewards or cashback scheme",
                    "📊 Review account activity and flag for re-engagement campaign"]
        elif prob > 0.3:
            recs = ["📧 Send personalised email with exclusive product offer",
                    "📱 Include in next marketing campaign wave",
                    "⭐ Enrol in loyalty programme"]
        else:
            recs = ["✅ Customer is stable — standard engagement sufficient",
                    "📈 Consider upsell opportunities for additional products"]

        st.markdown("#### 💡 Recommended Actions")
        for r in recs:
            st.markdown(f"<div class='insight-box'>{r}</div>", unsafe_allow_html=True)
