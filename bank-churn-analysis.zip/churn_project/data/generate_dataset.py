import pandas as pd
import numpy as np

np.random.seed(42)
n = 1000

age = np.random.randint(18, 70, n)
tenure = np.random.randint(0, 72, n)
balance = np.round(np.random.uniform(0, 250000, n), 2)
num_products = np.random.choice([1,2,3,4], n, p=[0.5,0.35,0.1,0.05])
has_credit_card = np.random.choice([0,1], n, p=[0.3,0.7])
is_active = np.random.choice([0,1], n, p=[0.4,0.6])
estimated_salary = np.round(np.random.uniform(15000, 200000, n), 2)
geography = np.random.choice(['India','Germany','France'], n, p=[0.5,0.25,0.25])
gender = np.random.choice(['Male','Female'], n)
credit_score = np.random.randint(300, 850, n)
campaign_calls = np.random.randint(0, 10, n)
last_contact_days = np.random.randint(1, 365, n)
subscribed = np.random.choice([0,1], n, p=[0.53,0.47])

churn_prob = (
    0.3 * (tenure < 12).astype(int) +
    0.2 * (is_active == 0).astype(int) +
    0.2 * (num_products > 2).astype(int) +
    0.15 * (balance < 10000).astype(int) +
    0.1 * (credit_score < 500).astype(int) +
    0.05 * (age > 55).astype(int)
)
churn_prob = np.clip(churn_prob / churn_prob.max(), 0.05, 0.95)
churn = (np.random.rand(n) < churn_prob).astype(int)

df = pd.DataFrame({
    'CustomerID': [f'CUST{str(i).zfill(4)}' for i in range(1, n+1)],
    'Age': age,
    'Gender': gender,
    'Geography': geography,
    'CreditScore': credit_score,
    'Tenure': tenure,
    'Balance': balance,
    'NumOfProducts': num_products,
    'HasCrCard': has_credit_card,
    'IsActiveMember': is_active,
    'EstimatedSalary': estimated_salary,
    'CampaignCalls': campaign_calls,
    'LastContactDays': last_contact_days,
    'Subscribed': subscribed,
    'Churn': churn
})

df.to_csv('/home/claude/churn_project/data/bank_churn_data.csv', index=False)
print(f"Dataset: {len(df)} rows | Churned: {df['Churn'].sum()} ({df['Churn'].mean()*100:.1f}%)")
